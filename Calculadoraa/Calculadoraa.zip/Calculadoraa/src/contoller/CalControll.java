/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contoller;

import model.CalcModel;

/**
 *
 * @author aluno
 */
public class CalControll {

    public double somar(double valor1, double valor2) {
        CalcModel c = new CalcModel();
        c.setValor1(valor1);
        c.setValor2(valor2);

        return c.somar();
    }

    public double subtrair(double valor1, double valor2) {
        CalcModel c = new CalcModel();
        c.setValor1(valor1);
        c.setValor2(valor2);

        return c.subtrair();

    }

    public double multiplicar(double valor1, double valor2) {
        CalcModel c = new CalcModel();
        c.setValor1(valor1);
        c.setValor2(valor2);

        return c.multiplicar();
    }

    public double dividir(double valor1, double valor2) {
        CalcModel c = new CalcModel();
        c.setValor1(valor1);
        c.setValor2(valor2);

        return c.dividir();
    }

}
