
<html>
<head>

  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">
  <title>primeiro arquivo</title>


</head>
<body>

<form method="POST" action="frutainc1.php" name="form1">
  <table style="text-align: left; width: 50%; " align="center" border="1" cellpadding="2" cellspacing="2">



      <tr align="center">
	  <td colspan="2" rowspan="1">Inclus&atilde;o de Alunos</td></tr>

      <tr>

        <td>Nome:&nbsp;</td><td><input name="nomea"></td>

      </tr>
      <tr>

        <td>Tipo:&nbsp;</td><td><input name="termoa"></td>

      </tr>

      <tr>

        <td>Curso:&nbsp;</td><td><input name="cursoa"></td>

      </tr>




      <tr>

        <td><input value="&lt;&lt; Limpar &gt;&gt;" type="reset"></td>

        <td><input value="&lt;&lt; Gravar &gt;&gt;" type="submit"></td>

      </tr>


  </table>

</form>

</body>
</html>
