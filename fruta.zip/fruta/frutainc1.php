<html>
<head>
    <title>Formulário dados de Estoque</title>
</head>
<body>
 <?php
$nomef       = $_POST['nomef'];
$tipof      = $_POST['tipof'];
$dataf      = $_POST['dataf'];

include('./conect.php');

$query = "insert into estoque values(null,'$nomef','$tipof','$dataf')";

$q1    = mysqli_query($con,$query);    //conexão que vem do arquivo conect.php

 ?>

<table style="text-align: left; width: 100px;" border="1"
 cellpadding="2" cellspacing="2">
    <tr align="center">
      <td colspan="2" rowspan="1">Dados da Estoque</td>
    </tr>
    <tr>
      <td style="text-align: left;">Nome:</td>
      <td style="text-align: center;"><input size="30"
 name="aluno" value="<?php echo $nomef;?>"></td>
    </tr>
    <tr>
      <td style="text-align: left;">Tipo:</td>
      <td style="text-align: left;"><input size="10"
 name="tipof" value="<?php echo $tipof;?>"></td>
    </tr>
    <tr>
      <td style="text-align: left;">Data:</td>
      <td style="text-align: left;"><input size="11"
 name="dataf" value="<?php echo $dataf;?>"></td>
    </tr>

      <td style="text-align: center;"></td>
      <td style="text-align: center;"></td>
    </tr>
</table>

<br>
</body>
</html>

