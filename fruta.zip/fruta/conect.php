<?php
$dbname = "fruta";
$servername = "localhost";
$username = "lata";
$password = "1234";

// Create connection
$con   = mysqli_connect($servername, $username, $password, $dbname);

//$banco = mysqli_select_db($dbname, $con);

?>